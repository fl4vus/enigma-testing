#include <string>
#include <algorithm>
#include "functions.cpp"

class Rotor {
public:
	char notch;
	int num;
	string primary;
	string secondary;
	
	// CONSTRUCTOR
	int Rotor(int r_num, string sec_key, char r_notch) {
		num = r_num;
		secondary = sec_key;
		for (int i = 0; i < 26; i++) {
			primary[i] = alphabet[i];
		}
		notch = r_notch;
		return 1;
	}
	
};

class Reflector {
public:
	char num;
	string primary;
	string secondary;
	
	// CONSTRUCTOR
	int Refector(char r_num, string sec_key) {
		num = r_num;
		secondary = sec_key;
		for (int i = 0; i < 26; i++) {
			primary[i] = alphabet[i];
		}
		return1;
	}
};

class Plugboard {
public:
	string primary;
	string secondary;
	
	// CONSTRUCTOR
	int Plugboard(int *swap_list) {
		for (int i = 0; i < 26; i++) {
			primary[i] = alphabet[i];
			secondary[i] = alphabet[i];
		}
		int iterator;
		char temp_char_a;
		char temp_char_b;
		int index_a = 0;
		int index_b = 0;
		while (temp_char_a != '\0' || iterator != 13) {
			temp_char_a = *(swap_list + 2*iterator);
			swap_str(secondary[search(alphabet, *(swap_list + 2*iterator))], secondary[search(alphabet, *(swap_list + 2*iterator + 1))]);
			iterator++;
		}
		return 1;
	}
};
		
	
	
	