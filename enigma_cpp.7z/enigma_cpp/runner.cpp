#include <iostream>
#include <string>
#include <algorithm>

#include "helper.hpp"
//#include "functions.cpp"
#include "components.cpp"
#define EXIT_CACHE_NOT_CREATED 0x01

using namespace std;

int get_wire(char* swap_list, string *wire, int iteration) {
	string temp;
	cout << iteration + 1 << ": ";
	cin >> temp;
	
	if (temp.length() != 2) {
		cout << "\nCAN ONLY SWAP TWO LETTERS AT ONCE! INVALID INPUT!" << endl;
		return -1;		
	}
	
	if (temp[0] == temp[1]) {
		cout << "CANNOT REPEAT LETTERS IN SAME PAIR! INVALID INPUT!" << endl;
		return -1;
	}
	
	for (int i = 0; i < 2; i++) {
		if (search(alphabet_lower, 26, char(temp[i])) == -1) {
			cout << "\n" << char(temp[i]) << " IS NOT A VALID MEMBER OF THE LOWERCASE APLHABET! INVALID INPUT!" << endl;
		}
		if (search(swap_list, 13, char(temp[i])) != -1) {
			cout << "\nCANNOT REPEAT LETTERS FOR SWAPPING! INVALID INPUT!" << endl;
			return -1;
		}
	}
	transform(temp.begin(), temp.end(), temp.begin(), ::toupper);
	*wire = temp;
	return 1;
}
	
int main() {
	help();
	
	rotor_i = Rotor(1, "EKMFLGDQVZNTOWYHXUSPAIBRCJ", 'Q')
	rotor_ii = Rotor(2, "AJDKSIRUXBLHWTMCQGZNPYFVO", 'E')
	rotor_iii = Rotor(3, "BDFHJLCPRTXVZNYEIWGAKMUSQO", 'V')
	rotor_iv = Rotor(4, "ESOVPZJAYQUIRHXLNFTGKDCMWB", 'J')
	rotor_v = Rotor(5, "VZBRGITYUPSDNHLXAWMJQOFECK", 'Z')

	reflector_a = Reflector(1, "EJMZALYXVBWFCRQUONTSPIKHGD")
	reflector_b = Reflector(2, "YRUHQSLDPXNGOKMIEBFZCWVJAT")
	reflector_c = Reflector(3, "FVPJIAOYEDRZXWGCTKUQSBNMHL")
	
	string inputs;
	string assembly;
	int plugs = 0;
	string wire;
	
	char plug_swaps[13];
	
	int flag = 0;
	while (flag != 1) {
		flag = get_input(&inputs);
	}
	transform(inputs.begin(), inputs.end(), inputs.begin(), ::toupper);
	flag = 0;
	while (flag != 1) {
		flag = get_assembly(&assembly);
	}
	flag = 0;
	while (flag != 1) {
		flag = get_plugs(&plugs);
	}
	flag = 0;
	
	for (int i = 0; i < 13; i++) {
		plug_swaps[i] = '\0';
	}
	
	if (plugs > 0) {
		cout << "\nEnter plugboard combinations (eg.: ab, to swap A and B on the plugboard): " << endl;
		for (int j = 0; j < plugs; j++) {
			while (flag != 1) {
				flag = get_wire(plug_swaps, &wire, j);
			}
			flag = 0;
			*(plug_swaps + 2*j) = char(wire[0]);
			*(plug_swaps + 2*j + 1) = char(wire[1]);
		}
	}
	
	char ch = '$';
	int iter = 0;
	
	cout << "\nInput: " << inputs << endl;
	cout << "Assembly Code: " << assembly << endl;
	
	if (plugs > 0) {
		cout << "Plugboard Swap Pair(s): | ";
		
		while (ch != '\0') {
			ch = plug_swaps[iter];
			cout << ch << " ";
			if (iter % 2 != 0) {
				cout << "| ";
			}
			iter++;
		}
		cout << endl;
	}
	
	return 0;
}