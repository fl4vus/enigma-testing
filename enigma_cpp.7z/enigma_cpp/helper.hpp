#include <iostream>
using namespace std;

int help() {
	cout << "RIYAN'S ENIGMA SIMULATOR" << endl;
	cout << "This is my hobby project on creating a code-based engima machine. This sumilator uses the historical Rotor I, II, III, IV, V, and Reflector A, B, and C as its swappable components." << endl;
	return 1;
}