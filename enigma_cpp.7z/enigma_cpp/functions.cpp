#include <iostream>
#include <string>
#include <iostream>
#include <string>
using namespace std;

char alphabet[26] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
char alphabet_lower[26] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

int search(char *array, int len, char key) {
	for (int i = 0; i < len; i++) {
		if (*(array + i) == key) {
			return i;
		}
	}
	
	return -1;
}
	
int swap_str(string& str, int index1, int index2) { 
	if (index1 >= 0 && index1 < str.length() && index2 >= 0 && index2 < str.length()) { 
		char temp = str[index1]; 
		str[index1] = str[index2]; 
		str[index2] = temp;
		return 1;
	} 
	else { 
		cout << "Swap: INVALID INDICES" << endl; 
		return -1;
	} 
}

int cycle_str(string *str) {
	string temp;
	int size;
	
	temp = *str;
	size = temp.length();
	
	for (int i = 0; i < size - 1; i++) {
		swap_str(temp, i, i + 1);
	}
	
	*str = temp;
	//cout << *str << endl;
	return 1;
}
	
int get_input(string *inputs) {
	cout << "\nEnter input string: ";
	getline(cin, *inputs);
	//cout << *inputs << endl;
	return 1;
}

int get_assembly(string *assembly) {
	string temp;
	cout << "\nEnter assembly combination: ";	
	cin >> temp;
	char reflector = temp.back();
	
	if (temp.length() != 4) {
		cout << "INVALID FORMAT!" << endl;
		return -1;		
	}
	if (!(reflector == 'a' || reflector == 'b' || reflector == 'c')) { 
		cout << "INVALID FORMAT" << endl;
		return -1;
	}
	for (int i = 0; i < 3; ++i) { 
		if (temp[i] < '1' || temp[i] > '5') { 
			cout << "INVALID FORMAT!" << endl;
			return -1;
		} 
	}
	*assembly = temp;
	return 1;
}
		
int get_plugs(int *plugs) {
	int temp;
	cout << "\nEnter no. of swapped pairs: " ;
	cin >> temp;
	
	if (temp > 13 || temp < 0) {
		cout << "CANNOT SWAP MORE THAN 13 PAIRS IN THE ALPHABET! INVALID INPUT!" << endl;
		return -1;
	}
	
	*plugs = temp;
	return 1;
}
